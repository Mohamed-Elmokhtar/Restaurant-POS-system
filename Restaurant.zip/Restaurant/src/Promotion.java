public class Promotion {   
    protected int discountPercentage;
    
    protected Promotion(IntDiscountCoupon coupon) {
        this.discountPercentage = coupon.getDiscountPercentage();
    }
}
