public class Food extends Item {
    
    public Food(String name, double price) {
        super(name, price);
    }
}
