public class Prcnt20DiscountImpl implements IntDiscountCoupon {
    private int discountPercentage;
    
    public Prcnt20DiscountImpl() {
        this.discountPercentage = 20;
    }
    
    @Override
    public int getDiscountPercentage() {
        return this.discountPercentage;
    }
}