public class Prcnt10DiscountImpl implements IntDiscountCoupon {
    private int discountPercentage;
    
    public Prcnt10DiscountImpl() {
        this.discountPercentage = 10;
    }
    
    @Override
    public int getDiscountPercentage() {
        return this.discountPercentage;
    }
}