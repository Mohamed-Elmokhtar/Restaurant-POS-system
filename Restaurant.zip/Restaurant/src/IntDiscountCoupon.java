public interface IntDiscountCoupon {
    public int getDiscountPercentage();
}
