import java.util.*;

public class DrinkMenu {
    protected ArrayList<Drink> drinks = new ArrayList<>();
    
    public DrinkMenu() {
        initFoods();
    }
    
    private void initFoods() {
        drinks.add(new Drink("Pepsi", 2.5));
        drinks.add(new Drink("Seven-Up", 2.5));
        drinks.add(new Drink("Fanta", 2.5));
        drinks.add(new Drink("Ice Tea", 2.5));
        drinks.add(new Drink("Water", 1));
        drinks.add(new Drink("Coffee", 3));
        drinks.add(new Drink("Tea", 3));
        drinks.add(new Drink("Orange", 5));
        drinks.add(new Drink("Watermelon", 5));
        drinks.add(new Drink("Lemon", 5));
    }
    
    public Drink getDrinkByName(String name) {
        for (Drink drink: drinks) {
            if (drink.getName().equals(name))
                return drink;
        }
        return null;
    }
}
