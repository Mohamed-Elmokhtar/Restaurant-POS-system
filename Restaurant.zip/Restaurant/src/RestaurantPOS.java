import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

public class RestaurantPOS extends JFrame {
    protected FoodMenu foods;
    protected DrinkMenu drinks;
    protected Bill bill;
    private JLabel aftrDiscountLabel;
    private JButton applyCouponButton;
    private JButton beefBurgerButton;
    private JButton beefShawarmaButton;
    private JLabel bfrDiscountLabel;
    private JButton billButton;
    private JButton cancelButton;
    private JButton chickBurgerButton;
    private JButton chickPizzaButton;
    private JButton chickShawrmaButton;
    private JButton chzPizzaButton;
    private JButton coffeeButton;
    private JTable customerBillTable;
    private JTextField discount;
    private JLabel discountAmntLabel;
    private JComboBox<String> discountCoupon;
    private JPanel drinkMenu;
    private JScrollPane drinkPane;
    private JLabel dscntCouponLable;
    private JButton fantaButton;
    private JPanel foodMenu;
    private JScrollPane foodPane;
    private JButton friedChickButton;
    private JButton friesButton;
    private JButton grlcBreadButton;
    private JButton iceTeaButton;
    private JPanel jPanel1;
    private JPanel jPanel2;
    private JScrollPane jScrollPane1;
    private JButton lemonJuiceButton;
    private JButton melonJuiceButton;
    private JTabbedPane menu;
    private JButton mzrlaStickButton;
    private JButton orangeJuiceButton;
    private JPanel paymentDetails;
    private JButton pepprniPizaaButton;
    private JButton pepsiButton;
    private JButton removeButton;
    private JButton sevenUpButton;
    private JButton shrimpButton;
    private JTextField subTotal;
    private JButton teaButton;
    private JTextField total;
    private JButton waterButton;

    public RestaurantPOS() {
        initRestaurantPOSInterface();
    }
                          
    private void initRestaurantPOSInterface() {
        foods = new FoodMenu();
        drinks = new DrinkMenu();
        jPanel2 = new JPanel();
        menu = new JTabbedPane();
        drinkPane = new JScrollPane();
        drinkMenu = new JPanel();
        sevenUpButton = new JButton();
        pepsiButton = new JButton();
        orangeJuiceButton = new JButton();
        fantaButton = new JButton();
        melonJuiceButton = new JButton();
        lemonJuiceButton = new JButton();
        waterButton = new JButton();
        teaButton = new JButton();
        coffeeButton = new JButton();
        iceTeaButton = new JButton();
        foodPane = new JScrollPane();
        foodMenu = new JPanel();
        beefBurgerButton = new JButton();
        chickBurgerButton = new JButton();
        beefShawarmaButton = new JButton();
        chickShawrmaButton = new JButton();
        chzPizzaButton = new JButton();
        shrimpButton = new JButton();
        pepprniPizaaButton = new JButton();
        friedChickButton = new JButton();
        grlcBreadButton = new JButton();
        mzrlaStickButton = new JButton();
        friesButton = new JButton();
        chickPizzaButton = new JButton();
        jScrollPane1 = new JScrollPane();
        customerBillTable = new JTable();
        paymentDetails = new JPanel();
        discountCoupon = new JComboBox<>();
        applyCouponButton = new JButton();
        jPanel1 = new JPanel();
        bfrDiscountLabel = new JLabel();
        discountAmntLabel = new JLabel();
        aftrDiscountLabel = new JLabel();
        subTotal = new JTextField();
        discount = new JTextField();
        total = new JTextField();
        cancelButton = new JButton();
        billButton = new JButton();
        removeButton = new JButton();
        dscntCouponLable = new JLabel();

        GroupLayout jPanel2Layout = new GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 100, Short.MAX_VALUE));
        jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 100, Short.MAX_VALUE));

        ImageIcon icon = new ImageIcon(getClass().getResource("restIcon.png"));
        this.setIconImage(icon.getImage());
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setTitle("My Restaurant");
        this.setBackground(new Color(204, 204, 204));
        this.setResizable(false);

        menu.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        menu.setFocusable(false);
        menu.setFont(new Font("Tahoma", 1, 12));
        
        drinkPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        drinkPane.setFocusable(false);
        
        sevenUpButton.setFont(new Font("Tahoma", 1, 8));
        sevenUpButton.setIcon(new ImageIcon(getClass().getResource("/seven-up.png")));
        sevenUpButton.setText("Seven-Up (RM 2.5)");
        sevenUpButton.setFocusable(false);
        sevenUpButton.setHorizontalTextPosition(JButton.CENTER);
        sevenUpButton.setVerticalTextPosition(JButton.TOP);
        sevenUpButton.addActionListener(e -> sevenUpButtonActionPerformed());

        pepsiButton.setFont(new Font("Tahoma", 1, 8));
        pepsiButton.setIcon(new ImageIcon(getClass().getResource("/pepsi.png")));
        pepsiButton.setText("Pepsi (RM 2.5)");
        pepsiButton.setFocusable(false);
        pepsiButton.setHorizontalTextPosition(JButton.CENTER);
        pepsiButton.setVerticalTextPosition(JButton.TOP);
        pepsiButton.addActionListener( e -> pepsiButtonActionPerformed());

        orangeJuiceButton.setFont(new Font("Tahoma", 1, 8)); 
        orangeJuiceButton.setIcon(new ImageIcon(getClass().getResource("/orange_juice.png"))); 
        orangeJuiceButton.setText("Orange Juice (RM 5)");
        orangeJuiceButton.setFocusable(false);
        orangeJuiceButton.setHorizontalTextPosition(JButton.CENTER);
        orangeJuiceButton.setVerticalTextPosition(JButton.TOP);
        orangeJuiceButton.addActionListener(e -> orangeJuiceButtonActionPerformed());

        fantaButton.setFont(new Font("Tahoma", 1, 8)); 
        fantaButton.setIcon(new ImageIcon(getClass().getResource("/fanta.png"))); 
        fantaButton.setText("Fanta (RM 2.5)");
        fantaButton.setFocusable(false);
        fantaButton.setHorizontalTextPosition(JButton.CENTER);
        fantaButton.setVerticalTextPosition(JButton.TOP);
        fantaButton.addActionListener(e -> fantaButtonActionPerformed());

        melonJuiceButton.setFont(new Font("Tahoma", 1, 8)); 
        melonJuiceButton.setIcon(new ImageIcon(getClass().getResource("/watermelon_juice.png"))); 
        melonJuiceButton.setText("Watermelon Juice (RM 5)");
        melonJuiceButton.setFocusable(false);
        melonJuiceButton.setHorizontalTextPosition(JButton.CENTER);
        melonJuiceButton.setVerticalTextPosition(JButton.TOP);
        melonJuiceButton.addActionListener(e -> melonJuiceButtonActionPerformed());

        lemonJuiceButton.setFont(new Font("Tahoma", 1, 8)); 
        lemonJuiceButton.setIcon(new ImageIcon(getClass().getResource("/lemon_juice.png"))); 
        lemonJuiceButton.setText("Lemon Juice (RM 5)");
        lemonJuiceButton.setFocusable(false);
        lemonJuiceButton.setHorizontalTextPosition(JButton.CENTER);
        lemonJuiceButton.setVerticalTextPosition(JButton.TOP);
        lemonJuiceButton.addActionListener(e -> lemonJuiceButtonActionPerformed());

        waterButton.setFont(new Font("Tahoma", 1, 8)); 
        waterButton.setIcon(new ImageIcon(getClass().getResource("/water.png"))); 
        waterButton.setText("Water (RM 1)");
        waterButton.setFocusable(false);
        waterButton.setHorizontalTextPosition(JButton.CENTER);
        waterButton.setVerticalTextPosition(JButton.TOP);
        waterButton.addActionListener(e -> waterButtonActionPerformed());

        teaButton.setFont(new Font("Tahoma", 1, 8)); 
        teaButton.setIcon(new ImageIcon(getClass().getResource("/tea.png"))); 
        teaButton.setText("Tea (RM 3)");
        teaButton.setFocusable(false);
        teaButton.setHorizontalTextPosition(JButton.CENTER);
        teaButton.setVerticalTextPosition(JButton.TOP);
        teaButton.addActionListener(e -> teaButtonActionPerformed());

        coffeeButton.setFont(new Font("Tahoma", 1, 8)); 
        coffeeButton.setIcon(new ImageIcon(getClass().getResource("/coffee.png"))); 
        coffeeButton.setText("Coffee (RM 3)");
        coffeeButton.setFocusable(false);
        coffeeButton.setHorizontalTextPosition(JButton.CENTER);
        coffeeButton.setVerticalTextPosition(JButton.TOP);
        coffeeButton.addActionListener(e -> coffeeButtonActionPerformed());

        iceTeaButton.setFont(new Font("Tahoma", 1, 8)); 
        iceTeaButton.setIcon(new ImageIcon(getClass().getResource("/ice_tea.png"))); 
        iceTeaButton.setText("Ice Tea (RM 2.5)");
        iceTeaButton.setFocusable(false);
        iceTeaButton.setHorizontalTextPosition(JButton.CENTER);
        iceTeaButton.setVerticalTextPosition(JButton.TOP);
        iceTeaButton.addActionListener(e -> iceTeaButtonActionPerformed());
        
        GroupLayout drinkMenuLayout = new GroupLayout(drinkMenu);
        drinkMenu.setLayout(drinkMenuLayout);
        drinkMenuLayout.setHorizontalGroup(
            drinkMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(drinkMenuLayout.createSequentialGroup().addContainerGap()
            .addGroup(drinkMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(drinkMenuLayout.createSequentialGroup()
            .addComponent(pepsiButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(sevenUpButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)).addGroup(drinkMenuLayout.createSequentialGroup()
            .addComponent(fantaButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(orangeJuiceButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)).addGroup(drinkMenuLayout.createSequentialGroup()
            .addComponent(lemonJuiceButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(melonJuiceButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)).addGroup(drinkMenuLayout.createSequentialGroup()
            .addComponent(coffeeButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(iceTeaButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)).addGroup(drinkMenuLayout.createSequentialGroup()
            .addComponent(waterButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(teaButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE))).addGap(10, 10, 10))
        );
        
        drinkMenuLayout.setVerticalGroup(
            drinkMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(drinkMenuLayout.createSequentialGroup().addContainerGap()
            .addGroup(drinkMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(pepsiButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(sevenUpButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(drinkMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(fantaButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(orangeJuiceButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(drinkMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(lemonJuiceButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(melonJuiceButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(drinkMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(coffeeButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(iceTeaButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(drinkMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(waterButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(teaButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)).addGap(10, 10, 10))
        );

        drinkPane.setViewportView(drinkMenu);

        menu.addTab("Drink", drinkPane);
        
        foodPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        foodPane.setFocusable(false);

        foodMenu.setFocusable(false);

        beefBurgerButton.setFont(new Font("Tahoma", 1, 8)); 
        beefBurgerButton.setIcon(new ImageIcon(getClass().getResource("/burger_beef.png"))); 
        beefBurgerButton.setText("Beef Burger (RM 8.5)");
        beefBurgerButton.setFocusable(false);
        beefBurgerButton.setHorizontalTextPosition(JButton.CENTER);
        beefBurgerButton.setVerticalTextPosition(JButton.TOP);
        beefBurgerButton.addActionListener(e -> beefBurgerButtonActionPerformed());

        chickBurgerButton.setFont(new Font("Tahoma", 1, 8));
        chickBurgerButton.setIcon(new ImageIcon(getClass().getResource("/burger_chicken.png"))); 
        chickBurgerButton.setText("Chicken Burger (7.5)");
        chickBurgerButton.setFocusable(false);
        chickBurgerButton.setHorizontalTextPosition(JButton.CENTER);
        chickBurgerButton.setVerticalTextPosition(JButton.TOP);
        chickBurgerButton.addActionListener(e -> chickBurgerButtonActionPerformed());

        beefShawarmaButton.setFont(new Font("Tahoma", 1, 8));
        beefShawarmaButton.setIcon(new ImageIcon(getClass().getResource("/shawarma_beef.png")));
        beefShawarmaButton.setText("Beef Shawarma (RM 6)");
        beefShawarmaButton.setFocusable(false);
        beefShawarmaButton.setHorizontalTextPosition(JButton.CENTER);
        beefShawarmaButton.setVerticalTextPosition(JButton.TOP);
        beefShawarmaButton.addActionListener(e -> beefShawarmaButtonActionPerformed());

        chickShawrmaButton.setFont(new Font("Tahoma", 1, 8));
        chickShawrmaButton.setIcon(new ImageIcon(getClass().getResource("/shawarma_chicken.png")));
        chickShawrmaButton.setText("Chicken Shawarma (RM 5)");
        chickShawrmaButton.setFocusable(false);
        chickShawrmaButton.setHorizontalTextPosition(JButton.CENTER);
        chickShawrmaButton.setVerticalTextPosition(JButton.TOP);
        chickShawrmaButton.addActionListener(e -> chickShawrmaButtonActionPerformed());

        chzPizzaButton.setFont(new Font("Tahoma", 1, 8));
        chzPizzaButton.setIcon(new ImageIcon(getClass().getResource("/pizaa_cheese.png")));
        chzPizzaButton.setText("Cheese Pizza (RM 15)");
        chzPizzaButton.setFocusable(false);
        chzPizzaButton.setHorizontalTextPosition(JButton.CENTER);
        chzPizzaButton.setVerticalTextPosition(JButton.TOP);
        chzPizzaButton.addActionListener(e -> chzPizzaButtonActionPerformed());

        shrimpButton.setFont(new Font("Tahoma", 1, 8));
        shrimpButton.setIcon(new ImageIcon(getClass().getResource("/fried_shrimp.png"))); 
        shrimpButton.setText("Fried Shrimp (RM 10)");
        shrimpButton.setFocusable(false);
        shrimpButton.setHorizontalTextPosition(JButton.CENTER);
        shrimpButton.setVerticalTextPosition(JButton.TOP);
        shrimpButton.addActionListener(e -> shrimpButtonActionPerformed());

        pepprniPizaaButton.setFont(new Font("Tahoma", 1, 8)); 
        pepprniPizaaButton.setIcon(new ImageIcon(getClass().getResource("/pizaa_pepporoni.png"))); 
        pepprniPizaaButton.setText("Pepporoni Pizza (RM 15)");
        pepprniPizaaButton.setFocusable(false);
        pepprniPizaaButton.setHorizontalTextPosition(JButton.CENTER);
        pepprniPizaaButton.setVerticalTextPosition(JButton.TOP);
        pepprniPizaaButton.addActionListener(e -> pepprniPizaaButtonActionPerformed());

        friedChickButton.setFont(new Font("Tahoma", 1, 8)); 
        friedChickButton.setIcon(new ImageIcon(getClass().getResource("/fried_chicken.png"))); 
        friedChickButton.setText("Fried Chicken (RM 12)");
        friedChickButton.setFocusable(false);
        friedChickButton.setHorizontalTextPosition(JButton.CENTER);
        friedChickButton.setVerticalTextPosition(JButton.TOP);
        friedChickButton.addActionListener(e -> friedChickButtonActionPerformed());

        grlcBreadButton.setFont(new Font("Tahoma", 1, 8)); 
        grlcBreadButton.setIcon(new ImageIcon(getClass().getResource("/garlic_bread.png"))); 
        grlcBreadButton.setText("Garlic Bread (3 RM)");
        grlcBreadButton.setFocusable(false);
        grlcBreadButton.setHorizontalTextPosition(JButton.CENTER);
        grlcBreadButton.setVerticalTextPosition(JButton.TOP);
        grlcBreadButton.addActionListener(e -> grlcBreadButtonActionPerformed());

        mzrlaStickButton.setFont(new Font("Tahoma", 1, 8)); 
        mzrlaStickButton.setIcon(new ImageIcon(getClass().getResource("/mozarella_sticks.png"))); 
        mzrlaStickButton.setText("Mozarella Sticks (RM 3)");
        mzrlaStickButton.setFocusable(false);
        mzrlaStickButton.setHorizontalTextPosition(JButton.CENTER);
        mzrlaStickButton.setVerticalTextPosition(JButton.TOP);
        mzrlaStickButton.addActionListener(e -> mzrlaStickButtonActionPerformed());

        friesButton.setFont(new Font("Tahoma", 1, 8)); 
        friesButton.setIcon(new ImageIcon(getClass().getResource("/fries.png"))); 
        friesButton.setText("Fries (RM 3)");
        friesButton.setFocusable(false);
        friesButton.setHorizontalTextPosition(JButton.CENTER);
        friesButton.setVerticalTextPosition(JButton.TOP);
        friesButton.addActionListener(e -> friesButtonActionPerformed());

        chickPizzaButton.setFont(new Font("Tahoma", 1, 8)); 
        chickPizzaButton.setIcon(new ImageIcon(getClass().getResource("/pizaa_chicken.png"))); 
        chickPizzaButton.setText("Chicken Pizza (RM 15)");
        chickPizzaButton.setFocusable(false);
        chickPizzaButton.setHorizontalTextPosition(JButton.CENTER);
        chickPizzaButton.setVerticalTextPosition(JButton.TOP);
        chickPizzaButton.addActionListener(e -> chickPizzaButtonActionPerformed());

        GroupLayout foodMenuLayout = new GroupLayout(foodMenu);
        foodMenu.setLayout(foodMenuLayout);
        foodMenuLayout.setHorizontalGroup(
            foodMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(foodMenuLayout.createSequentialGroup().addContainerGap()
            .addGroup(foodMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(friesButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
            .addComponent(grlcBreadButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
            .addComponent(beefBurgerButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
            .addComponent(beefShawarmaButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
            .addComponent(chzPizzaButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
            .addComponent(shrimpButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(foodMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(chickBurgerButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
            .addComponent(chickShawrmaButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
            .addComponent(pepprniPizaaButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
            .addComponent(friedChickButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
            .addComponent(chickPizzaButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
            .addComponent(mzrlaStickButton, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)).addGap(10, 10, 10))
        );
        
        foodMenuLayout.setVerticalGroup(
            foodMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(foodMenuLayout.createSequentialGroup().addContainerGap()
            .addGroup(foodMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(chickBurgerButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(beefBurgerButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(foodMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(beefShawarmaButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(chickShawrmaButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(foodMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(chzPizzaButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(chickPizzaButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(foodMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(shrimpButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(pepprniPizaaButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(foodMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(friedChickButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(friesButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(foodMenuLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(grlcBreadButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(mzrlaStickButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)).addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        foodPane.setViewportView(foodMenu);

        menu.addTab("Food", foodPane);

        customerBillTable.setModel(new DefaultTableModel(new Object [][] {}, new String [] {"Item", "Qty", "Price"}));
        customerBillTable.setFocusable(false);
        customerBillTable.setGridColor(new Color(0, 0, 0));
        customerBillTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(customerBillTable);
        
        paymentDetails.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));

        discountCoupon.setFont(new Font("Tahoma", 1, 12));
        discountCoupon.setModel(new DefaultComboBoxModel<>(new String[] {"None", "10% Coupon", "20% Coupon"}));
        discountCoupon.setFocusable(false);

        applyCouponButton.setFont(new Font("Tahoma", 1, 12));
        applyCouponButton.setText("Apply Coupon");
        applyCouponButton.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        applyCouponButton.addActionListener(e -> applyCouponButtonActionPerformed());

        jPanel1.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));

        bfrDiscountLabel.setFont(new Font("Tahoma", 1, 12));
        bfrDiscountLabel.setText("Total Before Discount");

        discountAmntLabel.setFont(new Font("Tahoma", 1, 12));
        discountAmntLabel.setText("Discount Amount");

        aftrDiscountLabel.setFont(new Font("Tahoma", 1, 12)); 
        aftrDiscountLabel.setText("Total After Discount");

        subTotal.setEditable(false);
        subTotal.setFont(new Font("Tahoma", 1, 12)); 
        subTotal.setText("RM");
        subTotal.setFocusable(false);

        discount.setEditable(false);
        discount.setFont(new Font("Tahoma", 1, 12)); 
        discount.setText("RM");
        discount.setFocusable(false);

        total.setEditable(false);
        total.setFont(new Font("Tahoma", 1, 12));
        total.setText("RM");
        total.setFocusable(false);

        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap()
            .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(bfrDiscountLabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(discountAmntLabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(aftrDiscountLabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(subTotal).addComponent(discount).addComponent(total, GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE))
            .addContainerGap())
        );
        
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap()
            .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(bfrDiscountLabel).addComponent(subTotal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(discountAmntLabel).addComponent(discount, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(aftrDiscountLabel).addComponent(total, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
            .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        cancelButton.setFont(new Font("Tahoma", 1, 12));
        cancelButton.setText("Cancel Order");
        cancelButton.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        cancelButton.setFocusable(false);
        cancelButton.addActionListener(e -> cancelButtonActionPerformed());

        billButton.setFont(new Font("Tahoma", 1, 12));
        billButton.setText("Issue Bill");
        billButton.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        billButton.setFocusable(false);
        billButton.addActionListener(e -> billButtonActionPerformed());

        removeButton.setFont(new Font("Tahoma", 1, 12));
        removeButton.setText("Remove Item");
        removeButton.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        removeButton.setFocusable(false);
        removeButton.addActionListener(e -> removeButtonActionPerformed());

        dscntCouponLable.setFont(new Font("Tahoma", 1, 12));
        dscntCouponLable.setText("Discount Coupon");

        GroupLayout paymentDetailsLayout = new GroupLayout(paymentDetails);
        paymentDetails.setLayout(paymentDetailsLayout);
        paymentDetailsLayout.setHorizontalGroup(
            paymentDetailsLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(paymentDetailsLayout.createSequentialGroup()
            .addContainerGap().addGroup(paymentDetailsLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(applyCouponButton, GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
            .addComponent(discountCoupon, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(dscntCouponLable, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(paymentDetailsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(cancelButton, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)
            .addComponent(billButton, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)
            .addComponent(removeButton, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)).addGap(52, 52, 52))
        );
        
        paymentDetailsLayout.setVerticalGroup(
            paymentDetailsLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, paymentDetailsLayout.createSequentialGroup()
            .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(paymentDetailsLayout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(paymentDetailsLayout.createSequentialGroup()
            .addComponent(dscntCouponLable).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(discountCoupon, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(applyCouponButton, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE).addGap(8, 8, 8))
            .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE).addGroup(paymentDetailsLayout.createSequentialGroup()
            .addComponent(cancelButton, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(billButton, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(removeButton, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE).addGap(4, 4, 4))).addGap(69, 69, 69))
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap()
            .addComponent(menu, GroupLayout.PREFERRED_SIZE, 343, GroupLayout.PREFERRED_SIZE).addGap(18, 18, 18)
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(jScrollPane1)
            .addComponent(paymentDetails, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)).addContainerGap())
        );
        
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap()
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(menu, GroupLayout.PREFERRED_SIZE, 507, GroupLayout.PREFERRED_SIZE).addGroup(layout.createSequentialGroup()
            .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 380, GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(paymentDetails, GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))).addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        menu.getAccessibleContext().setAccessibleName("Drink");

        pack();
    }                     
    
    private void iceTeaButtonActionPerformed() {                                             
        Drink drink = drinks.getDrinkByName("Ice Tea");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{drink.getName(), "1", drink.getPrice()});
        calculateBill();
    }                                            

    private void teaButtonActionPerformed() {                                          
        Drink drink = drinks.getDrinkByName("Tea");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{drink.getName(), "1", drink.getPrice()});
        calculateBill();
    }                                         

    private void melonJuiceButtonActionPerformed() {                                                 
        Drink drink = drinks.getDrinkByName("Watermelon");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{drink.getName(), "1", drink.getPrice()});
        calculateBill();
    }                                                

    private void orangeJuiceButtonActionPerformed() {                                                  
        Drink drink = drinks.getDrinkByName("Orange");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{drink.getName(), "1", drink.getPrice()});
        calculateBill();
    }                                                 

    private void sevenUpButtonActionPerformed() {                                              
        Drink drink = drinks.getDrinkByName("Seven-Up");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{drink.getName(), "1", drink.getPrice()});
        calculateBill();
    }                                             

    private void chickPizzaButtonActionPerformed() {                                                 
        Food food = foods.getFoodByName("Chicken Pizza");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{food.getName(), "1", food.getPrice()});
        calculateBill();
    }                                                

    private void mzrlaStickButtonActionPerformed() {                                                 
        Food food = foods.getFoodByName("Mozarella Sticks");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{food.getName(), "1", food.getPrice()});
        calculateBill();
    }                                                

    private void grlcBreadButtonActionPerformed() {                                                
        Food food = foods.getFoodByName("Garlic Bread");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{food.getName(), "1", food.getPrice()});
        calculateBill();
    }                                               

    private void friedChickButtonActionPerformed() {                                                 
        Food food = foods.getFoodByName("Fried Chicken");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{food.getName(), "1", food.getPrice()});
        calculateBill();
    }                                                

    private void pepprniPizaaButtonActionPerformed() {                                                   
        Food food = foods.getFoodByName("Pepporoni Pizza");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{food.getName(), "1", food.getPrice()});
        calculateBill();
    }                                                  

    private void chickShawrmaButtonActionPerformed() {                                                   
        Food food = foods.getFoodByName("Chicken Shawarma");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{food.getName(), "1", food.getPrice()});
        calculateBill();
    }                                                  

    private void chickBurgerButtonActionPerformed() {                                                  
        Food food = foods.getFoodByName("Chicken Burger");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{food.getName(), "1", food.getPrice()});
        calculateBill();
    }                                                                                       

    private void billButtonActionPerformed() {                                           
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        int response;
        response = JOptionPane.showConfirmDialog(null, "Bill Issued Successfully", "Bill Notice", JOptionPane.OK_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            model.setRowCount(0);
            subTotal.setText("RM");
            discount.setText("RM");
            total.setText("RM");
        }
    }                                          
    
    private void beefBurgerButtonActionPerformed() {                                                 
        Food food = foods.getFoodByName("Beef Burger");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{food.getName(), "1", food.getPrice()});
        calculateBill();
    }                                                
               
    private void removeButtonActionPerformed() {                                             
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.removeRow(customerBillTable.getSelectedRow());
        calculateBill();
        discount.setText("RM");
        total.setText("RM");
    }                                            

    private void friesButtonActionPerformed() {                                            
        Food food = foods.getFoodByName("Fries");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{food.getName(), "1", food.getPrice()});
        calculateBill();
    }                                           

    private void shrimpButtonActionPerformed() {                                             
        Food food = foods.getFoodByName("Fried Shrimp");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{food.getName(), "1", food.getPrice()});
        calculateBill();
    }                                            

    private void chzPizzaButtonActionPerformed() {                                               
        Food food = foods.getFoodByName("Cheese Pizza");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{food.getName(), "1", food.getPrice()});
        calculateBill();
    }                                              

    private void beefShawarmaButtonActionPerformed() {                                                   
        Food food = foods.getFoodByName("Beef Shawarma");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{food.getName(), "1", food.getPrice()});
        calculateBill();
    }                                                  

    private void cancelButtonActionPerformed() {                                             
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.setRowCount(0);
        subTotal.setText("RM");
        discount.setText("RM");
        total.setText("RM");
    }                                            

    private void pepsiButtonActionPerformed() {                                            
        Drink drink = drinks.getDrinkByName("Pepsi");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{drink.getName(), "1", drink.getPrice()});
        calculateBill();
    }                                           

    private void fantaButtonActionPerformed() {                                            
        Drink drink = drinks.getDrinkByName("Fanta");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{drink.getName(), "1", drink.getPrice()});
        calculateBill();
    }                                           

    private void lemonJuiceButtonActionPerformed() {                                                 
        Drink drink = drinks.getDrinkByName("Lemon");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{drink.getName(), "1", drink.getPrice()});
        calculateBill();
    }                                                

    private void coffeeButtonActionPerformed() {                                             
        Drink drink = drinks.getDrinkByName("Coffee");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{drink.getName(), "1", drink.getPrice()});
        calculateBill();
    }                                            

    private void waterButtonActionPerformed() {                                            
        Drink drink = drinks.getDrinkByName("Water");
        DefaultTableModel model = (DefaultTableModel) customerBillTable.getModel();
        model.addRow(new Object[]{drink.getName(), "1", drink.getPrice()});
        calculateBill();
    }                                           

    private void applyCouponButtonActionPerformed() {                                                  
        String couponSelected = discountCoupon.getSelectedItem().toString();
        switch (couponSelected) {
            case "10% Coupon" -> {
                    Promotion promo = new Promotion(new Prcnt10DiscountImpl());
                    bill.setDiscount(bill.getBillPrice() * promo.discountPercentage/100);
                }
            case "20% Coupon" -> {
                    Promotion promo = new Promotion(new Prcnt20DiscountImpl());
                    bill.setDiscount(bill.getBillPrice() * promo.discountPercentage/100);
                }
            default -> bill.setDiscount(0);
        }
        
        discount.setText("RM " + String.valueOf(bill.getDiscount()));
        total.setText("RM " + String.valueOf(bill.getBillPrice() - bill.getDiscount()));
    }                                                 

    private void calculateBill() {
        bill = new Bill();
        bill.setBillPrice(0);
        for (int i = 0; i < customerBillTable.getRowCount(); i++)
            bill.setBillPrice(bill.getBillPrice() + Double.parseDouble(customerBillTable.getValueAt(i, 2).toString()));
        subTotal.setText("RM " + String.valueOf(bill.getBillPrice()));
    }
    
    public static void main(String args[]) {
        new RestaurantPOS().setVisible(true);
    }
}