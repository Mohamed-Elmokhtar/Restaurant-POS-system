import java.util.*;

public class FoodMenu {
    protected ArrayList<Food> foods = new ArrayList<>();
    
    public FoodMenu() {
        initFoods();
    }
    
    private void initFoods() {
        foods.add(new Food("Beef Burger", 8.5));
        foods.add(new Food("Chicken Burger", 7.5));
        foods.add(new Food("Beef Shawarma", 6));
        foods.add(new Food("Chicken Shawarma", 5));
        foods.add(new Food("Cheese Pizza", 15));
        foods.add(new Food("Chicken Pizza", 15));
        foods.add(new Food("Pepporoni Pizza",15));
        foods.add(new Food("Fried Chicken", 12));
        foods.add(new Food("Fried Shrimp", 10));
        foods.add(new Food("Fries", 3));
        foods.add(new Food("Garlic Bread", 3));
        foods.add(new Food("Mozarella Sticks", 3));
    }
    
    public Food getFoodByName(String name) {
        for (Food food: foods) {
            if (food.getName().equals(name))
                return food;
        }
        return null;
    }
}
